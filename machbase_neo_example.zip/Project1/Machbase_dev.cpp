/******************************************************************************
 * Copyright of this product 2013-2023,
 * MACHBASE Corporation(or Inc.) or its subsidiaries.
 * All Rights reserved.
 ******************************************************************************/

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <machbase_sqlcli.h>


#define MACHBASE_PORT_NO    5656
#define ERROR_CHECK_COUNT   100

#define RC_SUCCESS           0
#define RC_FAILURE          -1

#define UNUSED(aVar) do { (void)(aVar); } while(0)

#define CHECK_STMT_RESULT(aRC, aSTMT, aMsg)     \
    if( sRC != SQL_SUCCESS )                    \
    {                                           \
        printError(gEnv, gCon, aSTMT, aMsg);    \
        goto error;                             \
    }

#define CHECK_APPEND_RESULT(aRC, aEnv, aCon, aSTMT)             \
    if( !SQL_SUCCEEDED(aRC) )                                   \
    {                                                           \
        if( checkAppendError(aEnv, aCon, aSTMT) == RC_FAILURE ) \
        {                                                       \
            ;                                                   \
        }                                                       \
    }


SQLHENV     gEnv;
SQLHDBC     gCon;

void printError(SQLHENV aEnv, SQLHDBC aCon, SQLHSTMT aStmt, char* aMsg);
int connectDB();
void disconnectDB();
int executeDirectSQL(const char* aSQL, int aErrIgnore);
int createTable();
int appendOpen(SQLHSTMT aStmt);
int appendData(SQLHSTMT aStmt);
SQLBIGINT appendClose(SQLHSTMT aStmt);
char* parseQuotedString(char* str);
typedef struct {
    char date[10];
    char route[50];
    char station[50];
    int boardings;
    int alightings;
} Data;

int checkAppendError(SQLHENV aEnv, SQLHDBC aCon, SQLHSTMT aStmt)
{
    SQLINTEGER      sNativeError;
    SQLCHAR         sErrorMsg[SQL_MAX_MESSAGE_LENGTH + 1];
    SQLCHAR         sSqlState[SQL_SQLSTATE_SIZE + 1];
    SQLSMALLINT     sMsgLength;

    if (SQLError(aEnv, aCon, aStmt, sSqlState, &sNativeError,
        sErrorMsg, SQL_MAX_MESSAGE_LENGTH, &sMsgLength) != SQL_SUCCESS)
    {
        return RC_FAILURE;
    }

    printf("SQLSTATE-[%s], Machbase-[%d][%s]\n", sSqlState, sNativeError, sErrorMsg);

    if (sNativeError != 9604 &&
        sNativeError != 9605 &&
        sNativeError != 9606)
    {
        return RC_FAILURE;
    }

    return RC_SUCCESS;
}

// ����ǥ�� ���� ���ڿ� �Ľ� �Լ�
char* parseQuotedString(char* str) {
    char* start = strchr(str, '"');
    if (start != NULL) {
        char* end = strchr(start + 1, '"');
        if (end != NULL) {
            *end = '\0';
            return start + 1;
        }
    }
    return str;
}

void printError(SQLHENV aEnv, SQLHDBC aCon, SQLHSTMT aStmt, char* aMsg)
{
    SQLINTEGER      sNativeError;
    SQLCHAR         sErrorMsg[SQL_MAX_MESSAGE_LENGTH + 1];
    SQLCHAR         sSqlState[SQL_SQLSTATE_SIZE + 1];
    SQLSMALLINT     sMsgLength;

    if (aMsg != NULL)
    {
        printf("%s\n", aMsg);
    }

    if (SQLError(aEnv, aCon, aStmt, sSqlState, &sNativeError,
        sErrorMsg, SQL_MAX_MESSAGE_LENGTH, &sMsgLength) == SQL_SUCCESS)
    {
        printf("SQLSTATE-[%s], Machbase-[%d][%s]\n", sSqlState, sNativeError, sErrorMsg);
    }
}

void appendDumpError(SQLHSTMT    aStmt,
    SQLINTEGER  aErrorCode,
    SQLPOINTER  aErrorMessage,
    SQLLEN      aErrorBufLen,
    SQLPOINTER  aRowBuf,
    SQLLEN      aRowBufLen)
{
    char       sErrMsg[1024] = { 0, };
    char       sRowMsg[32 * 1024] = { 0, };

    UNUSED(aStmt);

    if (aErrorMessage != NULL)
    {
        strncpy(sErrMsg, (char*)aErrorMessage, aErrorBufLen);
    }

    if (aRowBuf != NULL)
    {
        strncpy(sRowMsg, (char*)aRowBuf, aRowBufLen);
    }

    fprintf(stdout, "Append Error : [%d][%s]\n[%s]\n\n", aErrorCode, sErrMsg, sRowMsg);
}


int connectDB()
{
    char sConnStr[1024];

    if (SQLAllocEnv(&gEnv) != SQL_SUCCESS)
    {
        printf("SQLAllocEnv error\n");
        return RC_FAILURE;
    }

    if (SQLAllocConnect(gEnv, &gCon) != SQL_SUCCESS)
    {
        printf("SQLAllocConnect error\n");

        SQLFreeEnv(gEnv);
        gEnv = SQL_NULL_HENV;

        return RC_FAILURE;
    }

    sprintf(sConnStr, "SERVER=127.0.0.1;UID=SYS;PWD=MANAGER;CONNTYPE=1;PORT_NO=%d", MACHBASE_PORT_NO);

    if (SQLDriverConnect(gCon, NULL,
        (SQLCHAR*)sConnStr,
        SQL_NTS,
        NULL, 0, NULL,
        SQL_DRIVER_NOPROMPT) != SQL_SUCCESS
        )
    {

        printError(gEnv, gCon, NULL, "SQLDriverConnect error");

        SQLFreeConnect(gCon);
        gCon = SQL_NULL_HDBC;

        SQLFreeEnv(gEnv);
        gEnv = SQL_NULL_HENV;

        return RC_FAILURE;
    }

    return RC_SUCCESS;
}

void disconnectDB()
{
    if (SQLDisconnect(gCon) != SQL_SUCCESS)
    {
        printError(gEnv, gCon, NULL, "SQLDisconnect error");
    }

    SQLFreeConnect(gCon);
    gCon = SQL_NULL_HDBC;

    SQLFreeEnv(gEnv);
    gEnv = SQL_NULL_HENV;
}

int executeDirectSQL(const char* aSQL, int aErrIgnore)
{
    SQLHSTMT sStmt = SQL_NULL_HSTMT;

    if (SQLAllocStmt(gCon, &sStmt) != SQL_SUCCESS)
    {
        if (aErrIgnore == 0)
        {
            printError(gEnv, gCon, sStmt, "SQLAllocStmt Error");
            return RC_FAILURE;
        }
    }

    if (SQLExecDirect(sStmt, (SQLCHAR*)aSQL, SQL_NTS) != SQL_SUCCESS)
    {

        if (aErrIgnore == 0)
        {
            printError(gEnv, gCon, sStmt, "SQLExecDirect Error");

            SQLFreeStmt(sStmt, SQL_DROP);
            sStmt = SQL_NULL_HSTMT;
            return RC_FAILURE;
        }
    }

    if (SQLFreeStmt(sStmt, SQL_DROP) != SQL_SUCCESS)
    {
        if (aErrIgnore == 0)
        {
            printError(gEnv, gCon, sStmt, "SQLFreeStmt Error");
            sStmt = SQL_NULL_HSTMT;
            return RC_FAILURE;
        }
    }
    sStmt = SQL_NULL_HSTMT;

    return RC_SUCCESS;
}

int createTable()
{
    int sRC;

    sRC = executeDirectSQL("DROP TABLE CLI_SAMPLE", 1);
    if (sRC != RC_SUCCESS)
    {
        return RC_FAILURE;
    }

    sRC = executeDirectSQL("CREATE TABLE CLI_SAMPLE(seq short, score integer, total long, percentage float, ratio double, id varchar(20), srcip ipv4, dstip ipv6, reg_date datetime, textlog text, image binary)", 0);
    if (sRC != RC_SUCCESS)
    {
        return RC_FAILURE;
    }

    return RC_SUCCESS;
}

int appendOpen(SQLHSTMT aStmt)
{
    const char* sTableName = "TAG";

    if (SQLAppendOpen(aStmt, (SQLCHAR*)sTableName, ERROR_CHECK_COUNT) != SQL_SUCCESS)
    {
        printError(gEnv, gCon, aStmt, "SQLAppendOpen Error");
        return RC_FAILURE;
    }

    return RC_SUCCESS;
}

int appendData(SQLHSTMT aStmt)
{
    FILE* sFp = NULL;
    char             line[1024];
    char* sToken;
    SQLBIGINT        sCount = 0;
    int              j;
    char transName[100] = "";
    Data data;
    SQLRETURN        sRC;

    SQL_APPEND_PARAM sParam[3];

    sFp = fopen("subway_ANSI.csv", "r");
    if (!sFp)
    {
        printf("file open error-subway\n");
        return RC_FAILURE;
    }

    printf("append data start\n");

    memset(line, 0, sizeof(line));
    memset(sParam, 0, sizeof(sParam));

    fgets(line, sizeof(line), sFp); // ��� ���� �б� (����)

    while (fgets(line, sizeof(line), sFp)) {
        // CSV ���� �Ľ�
        sToken = parseQuotedString(strtok(line, ","));
        strcpy(data.date, sToken);

        sToken = parseQuotedString(strtok(NULL, ","));
        strcpy(data.route, sToken);

        sToken = parseQuotedString(strtok(NULL, ","));
        strcpy(data.station, sToken);

        sToken = parseQuotedString(strtok(NULL, ","));
        data.boardings = atoi(sToken);

        sToken = parseQuotedString(strtok(NULL, ","));
        data.alightings = atoi(sToken);
        // ����� �̸� ���� �� ������ ��� �Ǵ� Ȱ��
        snprintf(transName, sizeof(transName), "%s_%s_����", data.route, data.station);

        sParam[0].mVar.mLength = strnlen(transName, 100);
        sParam[0].mVar.mData = transName;
        sParam[1].mDateTime.mTime = SQL_APPEND_DATETIME_STRING;
        sParam[1].mDateTime.mDateStr = data.date;
        sParam[1].mDateTime.mFormatStr = "YYYYMMDD";
        sParam[2].mDouble = data.boardings;
        sRC = SQLAppendDataV2(aStmt, sParam);
        CHECK_APPEND_RESULT(sRC, gEnv, gCon, aStmt);


        snprintf(transName, sizeof(transName), "%s_%s_����", data.route, data.station);

        sParam[0].mVar.mLength = strnlen(transName, 100);
        sParam[0].mVar.mData = transName;
        sParam[2].mDouble = data.alightings;
        sRC = SQLAppendDataV2(aStmt, sParam);
        CHECK_APPEND_RESULT(sRC, gEnv, gCon, aStmt);
    }

    printf("\nappend data end\n");

    fclose(sFp);

    return RC_SUCCESS;
}

SQLBIGINT appendClose(SQLHSTMT aStmt)
{
    SQLBIGINT sSuccessCount = 0;
    SQLBIGINT  sFailureCount = 0;

    if (SQLAppendClose(aStmt, &sSuccessCount, &sFailureCount) != SQL_SUCCESS)
    {
        printError(gEnv, gCon, aStmt, "SQLAppendClose Error");
        return RC_FAILURE;
    }

    printf("success : %ld, failure : %ld\n", sSuccessCount, sFailureCount);

    return sSuccessCount;
}

int main()
{
    SQLHSTMT    sStmt = SQL_NULL_HSTMT;

    SQLBIGINT   sCount = 0;

    if (connectDB() == RC_SUCCESS)
    {
        printf("connectDB success\n");
    }
    else
    {
        printf("connectDB failure\n");
        goto error;
    }

    if (SQLAllocStmt(gCon, &sStmt) != SQL_SUCCESS)
    {
        printError(gEnv, gCon, sStmt, "SQLAllocStmt Error");
        goto error;
    }

    if (appendOpen(sStmt) == RC_SUCCESS)
    {
        printf("appendOpen success\n");
    }
    else
    {
        printf("appendOpen failure\n");
        goto error;
    }

    if (SQLAppendSetErrorCallback(sStmt, appendDumpError) != SQL_SUCCESS)
    {
        printError(gEnv, gCon, sStmt, "SQLAppendSetErrorCallback Error");
        goto error;
    }

    appendData(sStmt);

    sCount = appendClose(sStmt);
    if (sCount >= 0)
    {
        printf("appendClose success\n");
    }
    else
    {
        printf("appendClose failure\n");
    }

    if (SQLFreeStmt(sStmt, SQL_DROP) != SQL_SUCCESS)
    {
        printError(gEnv, gCon, sStmt, "SQLFreeStmt Error");
        goto error;
    }
    sStmt = SQL_NULL_HSTMT;

    disconnectDB();

    return RC_SUCCESS;

error:
    if (sStmt != SQL_NULL_HSTMT)
    {
        SQLFreeStmt(sStmt, SQL_DROP);
        sStmt = SQL_NULL_HSTMT;
    }

    if (gCon != SQL_NULL_HDBC)
    {
        disconnectDB();
    }

    return RC_FAILURE;
}
